import DesignEditor from "../design-editor"

export default function Page() {
  // T-Shirt Front with chest area
  // return <DesignEditor
  //   mode="product"
  //   productSpec={{
  //     id: "tshirt-front",
  //     name: "T-Shirt Front",
  //     backgroundImage: "https://rendering.documents.cimpress.io/v1/dsc/preview?format=webp&category=design-stack&scene=https%3A%2F%2Fcdn.scenes.documents.cimpress.io%2Fv3%2Fassets%2F706b5db8-b2d4-4f6e-b2dd-c16c56b0b860%2Fcontent&width=1534&height=1534",
  //     printArea: { x: 180, y: 200, width: 200, height: 250 },
  //     canvasSize: { width: 500, height: 600 },
  //     productInfo: {
  //       type: "apparel",
  //       printAreaDescription: "Front chest area",
  //       maxPrintSize: '8" × 10"',
  //       dpi: 25,
  //     },
  //   }}
  // />

  // T-Shirt Pocket area (small print area)
  return (
    <DesignEditor
      mode="product"
      productSpec={{
        id: "tshirt-pocket",
        name: "T-Shirt Pocket",
        backgroundImage:
          "https://rendering.documents.cimpress.io/v1/dsc/preview?format=webp&category=design-stack&scene=https%3A%2F%2Fcdn.scenes.documents.cimpress.io%2Fv3%2Fassets%2F706b5db8-b2d4-4f6e-b2dd-c16c56b0b860%2Fcontent&width=1534&height=1534",
        printArea: { x: 350, y: 180, width: 100, height: 80 },
        canvasSize: { width: 500, height: 600 },
        productInfo: {
          type: "apparel",
          printAreaDescription: "Left chest pocket",
          maxPrintSize: '4" × 3.2"',
          dpi: 25,
        },
      }}
    />
  )
}
